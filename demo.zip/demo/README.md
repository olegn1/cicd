> mvn clean deploy
> java -jar ./target/demo-0.0.1-SNAPSHOT.jar